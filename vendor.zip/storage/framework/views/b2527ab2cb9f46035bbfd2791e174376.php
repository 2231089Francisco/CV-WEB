<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>CV </title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="cssfile/CV.css" rel="stylesheet">
  <!-- =======================================================
  * Template Name: iPortfolio
  * Updated: Mar 10 2023 with Bootstrap v5.2.3
  * Template URL: https://bootstrapmade.com/iportfolio-bootstrap-portfolio-websites-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Mobile nav toggle button ======= -->
  <i class="bi bi-list mobile-nav-toggle d-xl-none"></i>

  <!-- ======= Header ======= -->
  <header id="header">
    <div class="d-flex flex-column">

 
        <h1 class="text-light"><a href="index.html">Francisco</a></h1>
        <div class="social-links mt-3 text-center">
        <a href="https://www.instagram.com/jiannn.72/" class="instagram"><i class="bx bxl-instagram"></i></a>
          <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
          <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
        </div>
      </div>

      <nav id="navbar" class="nav-menu navbar">
        <ul>
          <li><a href="#about" class="nav-link scrollto"><i class="bx bx-user"></i> <span>Profile</span></a></li>
      </nav><!-- .nav-menu -->
    </div>
  </header><!-- End Header -->


  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container">

        <div class="section-title">
          <h2>About</h2>
          <p>Hai, saya francisco saya tamatan Sma Santo Yusup, saya sekarang merupakan mahasiswa Universitas Internasional Batam di jurusan 
            sistem informasi.saya bersedia bekerja dalam bidang apapun dan saya bisa bekerja dalam tekanan.
          </div>

          <section id="pendidikan" class="pendidikan">
      <div class="container">

        <div class="section-title">
          <h2>pendidikan</h2>
          <div class="clearfix"></div>
      <div class="contact-info clearfix">
        <ul class="list-content ">
          <li>  TK Santo Yusup
          <li>  SD Santo Yusup
          <li>  SMP Santo Yusup
          <li>  SMA Santo yusup
          </div>



          <section id="contact" class="contact">
      <div class="container">

        <div class="section-title">
          <h2>contact</h2>
      <div class="clearfix"></div>
      <div class="contact-info clearfix">
        <ul class="list-content ">
        	<li>call : +62 813 7112 7903</li> <!-- YOUR PHONE NUMBER  -->
        	<li>Mail : Framer529@gmail.com</li> <!-- YOUR EMAIL -->
        	<li>state and country :Indonesian,batam</li> <!-- YOUR STATE AND COUNTRY  -->
        </ul>
          </div>
        </div>

      </div>
    </section><!-- End About Section -->


  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/typed.js/typed.min.js"></script>
  <script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="JS/main.js"></script>

</body>

</html><?php /**PATH C:\Users\user\OneDrive\Desktop\laravel\example-app\resources\views/welcome.blade.php ENDPATH**/ ?>